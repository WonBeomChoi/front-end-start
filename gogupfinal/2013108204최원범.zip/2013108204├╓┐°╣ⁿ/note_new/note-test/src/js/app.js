set_note_ul(document.querySelector(".note_list"));
set_text_area(document.querySelector("#memo")); //textarea 설정 = memo_area
set_about_area(document.querySelector(".about_box")); //about 활성창 설정.
get_storage();
console.log("aa");
document.querySelector(".btn-fullscreen").addEventListener("click",full_screen);
document.querySelector(".btn-newnote").addEventListener("click",new_note);
document.querySelector(".btn-savenote").addEventListener("click",note_append);
document.querySelector(".btn-about").addEventListener("click",about_open);
document.querySelector(".close").addEventListener("click",about_close);
document.querySelector(".about_box").addEventListener("click",about_close);
document.querySelector(".btn-downnote").addEventListener("click",filedown);
memo_area.addEventListener('keyup',saving_note);
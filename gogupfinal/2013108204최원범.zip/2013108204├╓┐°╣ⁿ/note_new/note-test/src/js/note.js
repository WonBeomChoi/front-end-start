var memo_area;
var about_area;
var notes;
var ul;
function set_note_ul(doc) {
    ul = doc;
    make_list();
}
function make_list() { //노트리스트 생성
    if(typeof localStorage.note_list!="undefined"){
        notes = localStorage.note_list.split(" ");
        load_note_list();
    }
    
}
function del_note(event) {
    var key = event.target.className
    localStorage.note_list = localStorage.note_list.replace(key,"");
    localStorage.removeItem(key);
    make_list()
}
function load_note_list() { //노트목록 출력
    ul.innerText = "메모 목록"
    for(var i = 0; i<=notes.length-1; i++){
        if(notes[i]!=""){
            var li = document.createElement("li");
            var div = document.createElement("div");
            var del_btn = document.createElement("button");
            var load_btn = document.createElement("button");
            li.appendChild(document.createTextNode(notes[i]));
            del_btn.appendChild(document.createTextNode("삭제"));
            del_btn.setAttribute("id","del_btn");
            del_btn.setAttribute("class",notes[i]);
            del_btn.addEventListener("click",del_note);
            load_btn.appendChild(document.createTextNode("불러오기"));
            load_btn.setAttribute("id","load_btn");
            load_btn.setAttribute("class",notes[i]);
            load_btn.addEventListener("click",get_key_note)
            div.setAttribute("id","btn_con");
            div.append(del_btn);
            div.append(load_btn);
            li.append(div);
            ul.appendChild(li);
        }
    }
} 
function get_note_name(){ //노트이름 입력
    name = prompt("노트이름을 입력하세요","입력창");
    if(name == "null"){
        return "이름없음"
    }
    return name;
}
function get_key_note(event){ //키값으로 내용 불러오기
    var txt = localStorage.getItem(event.target.className);
    memo_area.value = txt;
    
}
function note_append() {
    var name = get_note_name()
    if(typeof localStorage.note_list=="undefined"){
        localStorage.setItem("note_list", name);
    }else{
        localStorage.setItem("note_list", localStorage.note_list+" "+name);
    }
    save_note(name);
    make_list();
}

function set_text_area(area) {
    memo_area = area;
}
function get_storage() {
    if(typeof get_note_txt()=="undefined"){
        memo_area.value = "";
        save_note("now_note");
    }else{
        window.onload = function(){
            memo_area.value = get_note_txt();
        }
    }
}

function get_file_name(){
    return prompt("파일이름을 입력하세요", "입력창");
}

function filedown(txt) {
    var blob = new Blob([get_note_txt()], {type:"text/plain;charset=utf-8"});
    saveAs(blob,get_file_name());
}
function get_note_txt() {
    if(localStorage.now_note=="undefined"){
        return "";
    }
    return localStorage.now_note;
}
function save_note(kye_name) {
    window.localStorage.setItem(kye_name, memo_area.value);
}
function saving_note() {
    save_note("now_note");
}
function new_note(){
    memo_area.value = "";
    saving_note("now_note")
}
function full_screen(params) {
    if(!document.fullscreen){
        // console.log("전체화면가즈아")
        document.documentElement.requestFullscreen();
    }
    else if(document.fullscreen){
        // console.log("화면작게 가즈아");
        document.exitFullscreen();
    }
}
function set_about_area(doc) {
    about_area = doc;
}
function about_open() {
    about_area.style.display="block";
}
function about_close(){
    about_area.style.display="none";
}


var memo_area;
var about_area;
function set_text_area(area) {
    memo_area = area;
}
function get_storage() {
    if(typeof get_note_txt()=="undefined"){
        memo_area.value = "";
    }else{
        window.onload = function(){
            memo_area.value = get_note_txt();
        }
    }
}


function get_file_name(){
    return prompt("파일이름을 입력하세요", "입력창");
}

function filedown(txt) {
    var blob = new Blob([get_note_txt()], {type:"text/plain;charset=utf-8"});
    saveAs(blob,get_file_name());
}

function save_note(kye_name) {
    window.localStorage.setItem(kye_name, memo_area.value);
}
function get_note_txt() {
    if(typeof localStorage.now_note=="undefined"){
        return "";
    }
    return localStorage.now_note;
}
function saving_note() {
    save_note("now_note");
}
function new_note(){
    memo_area.value = "";
    saving_note("now_note")
}
function full_screen(params) {
    if(!document.fullscreen){
        // console.log("전체화면가즈아")
        document.documentElement.requestFullscreen();
    }
    else if(document.fullscreen){
        // console.log("화면작게 가즈아");
        document.exitFullscreen();
    }
}
function set_about_area(doc) {
    about_area = doc;
}
function about_open() {
    about_area.style.display="block";
}
function about_close(){
    about_area.style.display="none";
}

